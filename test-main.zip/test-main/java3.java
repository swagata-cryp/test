import java.util.Scanner;

public class PangramChecker {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a sentence: ");
        String input = scanner.nextLine();
        
        if (checkIfPangram(input)) {
            System.out.println("The input is a pangram!");
        } else {
            System.out.println("The input is not a pangram.");
        }
    }

    private static boolean checkIfPangram(String input) {
        input = input.toLowerCase();
        int[] alphabetPresence = new int[26];

        for (int i = 0; i < input.length(); i++) {
            char currentChar = input.charAt(i);

            if (Character.isLowerCase(currentChar)) {
                alphabetPresence[currentChar - 'a'] = 1;
            }
        }

        // Check if all letters from 'a' to 'z' are present
        for (int present : alphabetPresence) {
            if (present == 0) {
                return false;
            }
        }

        return true;
    }
}