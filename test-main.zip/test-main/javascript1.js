function revWords(sentence) {
    let words = sentence.split(" ");
    // Create a stack for each word
    let reversedWords = [];
    // Iterate through each word and push the reversed word onto the stack
    for (let i = 0; i < words.length; i++) {
        let currentWord = words[i];
        let reversedWord = reverseString(currentWord);
        reversedWords.push(reversedWord);
    }
    // Join the reversed words into a sentence
    let reversedSentence = reversedWords.join(" ");
    return reversedSentence;
}
function reverseString(str) {
    return str.split("").reverse().join("");
}

// Example usage
let input = "This is a sunny day";
console.log("Original Sentence: " + input);
console.log("Reversed Words Sentence: " + revWords(input));