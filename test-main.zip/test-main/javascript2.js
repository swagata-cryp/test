function bubbleSortDescending(arr) {
    let n = arr.length;
    let swapped;

    do {
        swapped = false;

        for (let i = 0; i < n - 1; i++) {
            if (arr[i] < arr[i + 1]) {
                // Swap elements if they are in the wrong order
                let temp = arr[i];
                arr[i] = arr[i + 1];
                arr[i + 1] = temp;
                swapped = true;
            }
        }
        n--;
    } while (swapped);
    return arr;
}
let unsortedArray = [64, 34, 25, 12, 22, 11, 90];
let sortedArray = bubbleSortDescending(unsortedArray);

console.log("Original Array: " + unsortedArray);
console.log("Sorted Array (Descending): " + sortedArray);