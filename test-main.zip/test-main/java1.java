import java.util.Arrays;
import java.util.Random;

class shuffler {
    public static void main(String[] args) {
        int[] array = {1, 2, 3, 4, 5, 6, 7};
        shuffleArray(array);
        System.out.println("Shuffled Array: " + Arrays.toString(array));
    }
    
    public static void shuffleArray(int[] arr){
        int n = arr.length;
        Random random = new Random();
        
	// Following the Fisher-Yates shuffling algo
        for (int i = n - 1; i > 0; i--) {
            // Generate a random index j such that 0 <= j <= i
            int j = random.nextInt(i + 1);

            // Swap array[i] and array[j]
            int temp = arr[i];
            arr[i] = arr[j];
            arr[j] = temp;
        }
    }
}